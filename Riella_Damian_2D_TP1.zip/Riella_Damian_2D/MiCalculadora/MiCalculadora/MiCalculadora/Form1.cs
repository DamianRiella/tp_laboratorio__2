using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class FormCalculadora : Form
    {
        #region Contructor

        /// <summary>
        /// inicializa los componentes de la calculadora.
        /// </summary>
        public FormCalculadora()
        {
            InitializeComponent();
        }
        #endregion

        #region Metodos

        /// <summary> </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormCalculadora_Load(object sender, EventArgs e)
        {
        }


        /// <summary>Cierra la ventana.</summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }


        /// <summary>Limpian los textBox, el comboBox y el Label.</summary>
        private  void Limpiar()
        {
            txtNumero1.Text = " ";
            txtNumero2.Text = " ";
            cmbOperador.Text = " ";
            lblResultado.Text = " ";
        }

        /// <summary>LLama al metodo Limpiar.</summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar(); 
        }


        /// <summary> </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbOperador_SelectedIndexChanged(object sender, EventArgs e)
        {
        }


        /// <summary> </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {
        }



        /// <summary>Recibe el contenido de txtNumero1, txtNumero2 y cmbOperador, se los usa como parametros para el metodo Calculadora.Operar.</summary>
        /// <param name="Numero1">Valor pasado como string</param>
        /// <param name="Numero2">Valor pasado como string</param>
        /// <param name="Operador">Operador pasado como string</param>
        /// <returns>Retorna el resultado de la operacion en formato string.</returns>
        private static string Operar(string num1, string num2, string Operador)
        {
            Numero numeroUno, numeroDos;
            numeroUno = new Numero(num1);
            numeroDos = new Numero(num2);

            double resultado = Calculadora.Operar(numeroUno, numeroDos, Operador);
            return resultado.ToString();
        }



        /// <summary>LLama al metodo operar y asigana el valor devuelto por el metodo al lblResultado.Text.</summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOperar_Click(object sender, EventArgs e)
        {

          lblResultado.Text = FormCalculadora.Operar(txtNumero1.Text,txtNumero2.Text, cmbOperador.Text);

        }



        /// <summary> </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lblResultado_Click(object sender, EventArgs e)
        {
        }

        private void txtNumero2_TextChanged(object sender, EventArgs e)
        {
        }



        /// <summary>LLama al metodo Numero.DecimalBinario y asigan el valor devuelto al lblResultado.Text</summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButBinario_Click(object sender, EventArgs e)
        {
            lblResultado.Text = Numero.DecimalBinario(lblResultado.Text);
        }



        /// <summary>Valida que el lblResultado.Text no este vacio,luego llama al metodo Numero.BinarioDecimal y asigan el valor devuelto al lblResultado.Text</summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButDecimal_Click(object sender, EventArgs e)
        {
            if (lblResultado.Text != "")
            {
                lblResultado.Text = Numero.BinarioDecimal(lblResultado.Text);
            }
        }
    }
    #endregion
}
