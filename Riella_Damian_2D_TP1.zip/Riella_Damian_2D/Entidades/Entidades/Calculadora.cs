using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {
        #region Metrodos 

        /// <summary>Valida que el operador sea +,-,* o /.</summary>
        /// <param name="operador"></param>
        /// <returns>Devuelve el operador si esta ok, de lo contrario delvuelve 0.</returns
        private static string ValidarOperador(string operador)
        {
            if (operador == "+" || operador == "-" || operador == "/" || operador == "*")
            {
                return operador;
            }
            else
            {
                return "+";
            }
        } 

        /// <summary>Realiza la operacion pasada por parametro(operador) con los parametros num1 y num2 del tipo Numero.</summary>
        /// <param name="num1">Operador del tipo Numero.</param>
        /// <param name="num2">Operador del tipo Numero.</param>
        /// <param name="operador">Operador del tipo String.</param>
        /// <returns>Devuelve el resultado de la operacion y si fuese una divicion entre 0 devuelve double.MinValue.</returns>
        public static double Operar(Numero num1, Numero num2, string operador)
        {
            
            string valiOpe = ValidarOperador(operador);
            double resultado=0;

            switch (valiOpe)
            {
                case "+":
                           resultado= num1 + num2;
                           break;
                case "-":
                           resultado = num1 - num2;
                           break;
                case "/":
                            try
                            {
                              resultado = num1 / num2;
                            }
                            catch (DivideByZeroException)
                            {
                              resultado = double.MinValue;
                            }
                            break;
                case "*":
                            resultado= num1 * num2;
                           break;
            }

            return resultado;

        }

        #endregion
    }
}
